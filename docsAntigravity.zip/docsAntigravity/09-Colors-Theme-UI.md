# 09 - Colors, Theme & UI System Audit

This document details the visual design system, color palette tokens, typography rules, and UI inconsistencies in the Vytalis Intelligence frontend.

---

## Design System Tokens ([`Frontend/src/index.css`](file:///d:/VM%20Intelligence/Frontend/src/index.css))

### Primary & Secondary Color Palette
- **Primary Brand Accent**: `var(--color-primary, #0A84FF)` (Vibrant Apple-style Blue)
- **Primary Hover**: `var(--color-primary-hover, #0071E3)`
- **Primary Light Tint**: `var(--color-primary-light, rgba(10, 132, 255, 0.10))`
- **Secondary Accent**: `var(--color-secondary, #5E5CE6)` (Indigo / Purple)

### Semantic & Feedback Colors
- **Success / Positive Trend**: `var(--color-success, #30D158)` / Light: `rgba(48, 209, 88, 0.10)`
- **Warning / Neutral Trend**: `var(--color-warning, #FF9F0A)` / Light: `rgba(255, 159, 10, 0.10)`
- **Error / Negative Trend**: `var(--color-error, #E5484D)` / Light: `rgba(229, 72, 77, 0.10)`

### Neutral Surface & Background Colors
- **Page Background**: `var(--color-background)` (`#FFFFFF` light mode / `#0B0F17` dark mode)
- **Card Surface**: `var(--color-surface)` (`#F8FAFC` light mode / `#141A25` dark mode)
- **Primary Text**: `var(--color-text-primary)` (`#111827` light mode / `#F9FAFB` dark mode)
- **Secondary Text**: `var(--color-text-secondary)` (`#475569` light mode / `#9CA3AF` dark mode)
- **Border / Divider**: `var(--color-border)` (`#E2E8F0` light mode / `#1F2937` dark mode)

---

## Typography & Radius Tokens

### Font Family Stack
```css
font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display",
             "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
```

### Component Border Radius Tokens
- `var(--radius-sm, 4px)` - Badge & pill tags
- `var(--radius-input, 8px)` - Input text boxes & buttons
- `var(--radius-card, 12px)` - Metric cards & table containers
- `var(--radius-modal, 16px)` - Floating dialogs

---

## UI Audit & Inconsistencies Identified

### 1. Hardcoded Inline Colors in Auth Components
- **Exact File**: [`Frontend/src/app/router.jsx`](file:///d:/VM%20Intelligence/Frontend/src/app/router.jsx#L94)
- **Problem**: `LoginPage` and `SignupPage` render inline CSS styles with hardcoded hex fallbacks:
  ```jsx
  style={{ color: "var(--color-text-primary, #111827)", fontSize: "1.5rem" }}
  ```
- **Why it matters**: Bypasses CSS class reusability and creates maintenance drift.
- **Fix**: Move auth page styles into dedicated `.css` module files.

### 2. Duplicate Component Implementations
- **Exact Files**: `components/ui/MetricCard.jsx` vs `components/shared/MetricCard.jsx`
- **Problem**: `components/shared/MetricCard.jsx` uses hardcoded inline borders while `components/ui/MetricCard.jsx` consumes CSS custom properties.
- **Fix**: Replace references to `components/shared/MetricCard.jsx` with `components/ui/MetricCard.jsx`.
