# 05 - Database Structure & Model Schema

This document details every MongoDB collection, schema field, relationship, and index defined in the Vytalis Intelligence backend.

---

## Database Overview
- **Database Engine**: MongoDB
- **Object Data Modeling (ODM)**: Mongoose v9
- **Connection Setup**: `Backend/Src/config/db.js`
- **Total Collections**: 6 collections (`users`, `organizations`, `adminassignments`, `auditlogs`, `globalsettings`, `counters`).

---

## Collection Schemas & Relationships

### 1. `users` Collection ([`user.model.js`](file:///d:/VM%20Intelligence/Backend/Src/models/user.model.js))
- **Purpose**: Stores all system users across all roles (Root Admin, Admin, Client, Member).
- **Important Fields**:
  - `name` (String, required)
  - `email` (String, required, unique, lowercase)
  - `password` (String, required, select: false)
  - `role` (String, enum: `["root_admin", "admin", "client", "member"]`, default: `"client"`)
  - `status` (String, enum: `["active", "disabled"]`, default: `"active"`)
  - `organizationId` (ObjectId ref `Organization`)
  - `assignedClientId` (ObjectId ref `User`)
  - `assignedPermissions` (Array of `{ key: String, allowed: Boolean }`)
  - `isRootAdmin` (Boolean, default: `false`)
  - `rootAdminRank` (Number, unique, sparse)
  - `integrations` (Embedded subdocuments for `meta` and `shopify` accounts)
  - `preferences` (Object for active accounts, creative card settings, KPI card preferences, and hidden features)
- **Relationships**:
  - `organizationId` ➔ `Organization._id`
  - `assignedClientId` ➔ `User._id` (Client owner of a Member)
  - `createdBy` ➔ `User._id`
- **Existing Indexes**:
  - `{ email: 1 }` (Unique index created by `unique: true`)
  - `{ role: 1, status: 1, createdAt: -1 }`
  - `{ organizationId: 1, role: 1, status: 1 }`
  - `{ assignedClientId: 1, role: 1, status: 1 }`
  - `{ name: 1, email: 1 }`
  - `{ rootAdminRank: 1 }` (Unique, Sparse)

---

### 2. `organizations` Collection ([`organization.model.js`](file:///d:/VM%20Intelligence/Backend/Src/models/organization.model.js))
- **Purpose**: Stores multi-tenant brand organization entities.
- **Important Fields**:
  - `name` (String, required)
  - `ownerId` (ObjectId ref `User`, required)
  - `memberLimit` (Number, default: 5)
  - `status` (String, enum: `["active", "disabled"]`, default: `"active"`)
- **Relationships**:
  - `ownerId` ➔ `User._id` (The Client who owns the organization)
- **Existing Indexes**:
  - `{ ownerId: 1, status: 1 }`

---

### 3. `adminassignments` Collection ([`admin-assignment.model.js`](file:///d:/VM%20Intelligence/Backend/Src/models/admin-assignment.model.js))
- **Purpose**: Tracks which Admin agency managers are assigned to manage specific Client Organizations.
- **Important Fields**:
  - `adminId` (ObjectId ref `User`, required)
  - `organizationId` (ObjectId ref `Organization`, required)
  - `status` (String, enum: `["active", "inactive"]`, default: `"active"`)
- **Existing Indexes**:
  - `{ adminId: 1, organizationId: 1 }` (Unique compound index)
  - `{ organizationId: 1, status: 1 }`
  - `{ adminId: 1, status: 1 }`

---

### 4. `auditlogs` Collection ([`audit-log.model.js`](file:///d:/VM%20Intelligence/Backend/Src/models/audit-log.model.js))
- **Purpose**: Immutable security and administrative action audit trail.
- **Important Fields**:
  - `actorId` (ObjectId ref `User`, required)
  - `targetUserId` (ObjectId ref `User`)
  - `organizationId` (ObjectId ref `Organization`)
  - `action` (String, enum of 13 administrative actions)
  - `permissionKey` (String)
  - `oldValue` (Mixed)
  - `newValue` (Mixed)
- **Existing Indexes**:
  - `{ actorId: 1 }`
  - `{ targetUserId: 1 }`
  - `{ organizationId: 1 }`
  - `{ createdAt: -1 }`

---

### 5. `globalsettings` Collection ([`global-settings.model.js`](file:///d:/VM%20Intelligence/Backend/Src/models/global-settings.model.js))
- **Purpose**: System-wide feature restrictions set by Root Admin.
- **Important Fields**:
  - `globalDeniedPermissions` (Array of Strings)
  - `updatedBy` (ObjectId ref `User`)

---

### 6. `counters` Collection ([`counter.model.js`](file:///d:/VM%20Intelligence/Backend/Src/models/counter.model.js))
- **Purpose**: Auto-incrementing numeric sequences (e.g. rootAdminRank).
- **Important Fields**:
  - `_id` (String identifier)
  - `seq` (Number)
