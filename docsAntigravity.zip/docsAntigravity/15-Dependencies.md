# 15 - Dependencies & Package Audit

This document provides a complete audit of third-party dependencies defined in `Backend/package.json` and `Frontend/package.json`.

---

## Backend Dependency Inventory ([`Backend/package.json`](file:///d:/VM%20Intelligence/Backend/package.json))

| Package Name | Installed Version | Purpose & Usage | Audit Findings |
| :--- | :--- | :--- | :--- |
| `express` | `^5.2.1` | Core HTTP Web Application Framework | **Modern Major Version (v5)**. Clean middleware handling. |
| `mongoose` | `^9.9.1` | MongoDB Object Data Modeling (ODM) | **Latest Major Version**. Core data persistence layer. |
| `redis` | `^6.2.0` | Redis client for rate limiting | Active. Provides promise-based client. |
| `jsonwebtoken` | `^9.0.3` | JWT creation and verification | Core authentication dependency. |
| `bcryptjs` | `^3.0.3` | Password hashing algorithm | Pure JS implementation of bcrypt. |
| `joi` | `^18.2.3` | Schema validation | Core request payload validator. |
| `axios` | `^1.19.0` | External HTTP requests to Windsor API | Active. Used in `windsor.provider.js`. |
| `cookie-parser` | `^1.4.7` | HTTP cookie parsing middleware | Required for reading `access_token` cookies. |
| `cors` | `^2.8.6` | Cross-Origin Resource Sharing | Enforces origin whitelist. |
| `dotenv` | `^17.4.2` | Environment variable loader | Active. |

---

## Frontend Dependency Inventory ([`Frontend/package.json`](file:///d:/VM%20Intelligence/Frontend/package.json))

| Package Name | Installed Version | Purpose & Usage | Audit Findings |
| :--- | :--- | :--- | :--- |
| `react` | `^19.2.8` | UI Library | **Latest React 19 release**. |
| `react-dom` | `^19.2.8` | React DOM renderer | Active. |
| `react-router-dom`| `^7.18.2` | Client-side routing framework | **React Router v7**. Active. |
| `@dnd-kit/core` | `^6.3.1` | Drag and Drop framework | Used in `DashboardGrid.jsx` and widget customizer. |
| `@dnd-kit/sortable`| `^10.0.0` | Sortable list utilities | Active. |
| `@dnd-kit/utilities`| `^3.2.2` | Drag and drop helpers | Active. |
| `lucide-react` | `^1.31.0` | Icon set | Active icon renderer across all pages. |
| `vite` | `^8.2.0` | Build tool and dev server | Modern, fast bundler. |
| `oxlint` | `^1.75.0` | Fast JavaScript linter | Installed for linting (`npm run lint`). |

---

## Package Bundle Footprint Assessment

- **Overall Health**: EXCELLENT.
- **Dependencies footprint**: Both package manifests are remarkably clean and free of heavy legacy libraries (such as Lodash, Moment.js, or jQuery).
- **Recommendation**: Keep dependencies updated and monitor React 19 / Express 5 API stability.
