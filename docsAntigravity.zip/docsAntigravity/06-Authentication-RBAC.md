# 06 - Authentication & RBAC Hierarchy Audit

This document details the Role-Based Access Control (RBAC) architecture, organizational boundaries, and authority ceilings in Vytalis Intelligence.

---

## The 4-Tier Role Hierarchy

```
       ┌────────────────────────┐
       │       ROOT ADMIN       │  (Platform Owner - Unrestricted Authority)
       └───────────┬────────────┘
                   │
                   ▼
       ┌────────────────────────┐
       │         ADMIN          │  (Agency Manager - Manages Assigned Organizations)
       └───────────┬────────────┘
                   │
                   ▼
       ┌────────────────────────┐
       │         CLIENT         │  (Brand Owner - Manages Brand Organization & Members)
       └───────────┬────────────┘
                   │
                   ▼
       ┌────────────────────────┐
       │         MEMBER         │  (Staff/Employee - Custom Assigned Sub-Permissions)
       └────────────────────────┘
```

---

## Authority & Creation Matrix

| Action | Root Admin | Admin | Client | Member |
| :--- | :---: | :---: | :---: | :---: |
| **Create Admin** | YES | NO | NO | NO |
| **Create Client** | YES | YES | NO | NO |
| **Create Member** | YES | YES | YES | NO |
| **Assign Admin to Org** | YES | NO | NO | NO |
| **Grant/Revoke Permissions** | YES | YES (Assigned Orgs) | YES (Team Members) | NO |
| **Global Permission Restrictions**| YES | NO | NO | NO |
| **Access All Organizations** | YES | Assigned Orgs Only | Own Org Only | Own Org Only |

---

## Effective Permission Calculation Workflow

The system evaluates effective permissions in [`permission-calculator.util.js`](file:///d:/VM%20Intelligence/Backend/Src/utils/permission-calculator.util.js#L98) using a 7-step cascade:

```
                          [ Check Target User ]
                                    │
                       1. Is Root Admin / isRootAdmin?
                       ├── YES ➔ ALLOWED (Source: "root")
                       └── NO
                                    │
                       2. Is Account Status "disabled"?
                       ├── YES ➔ DENIED (Reason: "account_disabled")
                       └── NO
                                    │
                       3. Is Client/Member Organization "disabled"?
                       ├── YES ➔ DENIED (Reason: "organization_disabled")
                       └── NO
                                    │
                       4. Is key in GlobalSettings.globalDeniedPermissions?
                       ├── YES ➔ DENIED (Lock: "disabled_by_root_admin")
                       └── NO
                                    │
                       5. Evaluate Role Authority Ceiling:
                       ├── If ADMIN ➔ Return user.assignedPermissions value
                       ├── If CLIENT ➔ Check supervising Admin permissions first
                       │               If Admin denied ➔ DENIED ("disabled_by_admin")
                       │               Else ➔ Return Client user.assignedPermissions
                       └── If MEMBER ➔ Check parent Client permissions first
                                       If Client denied ➔ DENIED ("disabled_by_client")
                                       Else ➔ Return Member user.assignedPermissions
```

---

## MongoDB vs Redis Permission Source of Truth Verification

- **Architectural Requirement**: Redis MUST NOT be considered the source of truth for permissions. Permission source of truth MUST be MongoDB.
- **Code Audit Verification**:
  - In `Backend/Src/utils/permission-calculator.util.js`:
    ```js
    const invalidateUserPermissionCache = async (userId) => { return; };
    const invalidateOrgPermissionCache = async (orgId) => { return; };
    ```
  - `calculateEffectivePermission` queries MongoDB models directly (`User`, `Organization`, `GlobalSettings`, `AdminAssignment`).
  - **Verdict**: Fully compliant. Permission calculation reads directly from MongoDB without stale Redis permission caching.

---

## Security Audit & Privilege Risks

### 1. Privilege Escalation Endpoint (`profile.controller.js`)
- **Severity**: CRITICAL
- **File**: [`Backend/Src/controllers/profile.controller.js`](file:///d:/VM%20Intelligence/Backend/Src/controllers/profile.controller.js#L24)
- **Problem**: Endpoint `POST /api/profile/upgrade-role` accepts a key parameter `ADMIN_UPGRADE_KEY` and upgrades any caller account to `admin` (or `isRootAdmin` if no root admin exists).
- **Fix**: Remove `upgradeRole` controller function and route handler.

### 2. Plain System Access Code During Signup (`auth.service.js`)
- **Severity**: HIGH
- **File**: [`Backend/Src/services/auth.service.js`](file:///d:/VM%20Intelligence/Backend/Src/services/auth.service.js)
- **Problem**: Signup requires a static string matching `process.env.SYSTEM_ACCESS_CODE`. Anyone with access to the code can register a Client account.
- **Fix**: Replace static system access code with database-backed invitation tokens.
