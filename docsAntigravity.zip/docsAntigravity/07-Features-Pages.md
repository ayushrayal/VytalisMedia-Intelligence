# 07 - Major Features & Page Inventory

This document details the functional features and page modules available in Vytalis Intelligence.

---

## Major Feature Breakdown

```
Vytalis Intelligence Platform
 ├── 1. Business Overview Dashboard (Unified Meta + Shopify KPI Cards & Widgets)
 ├── 2. Meta Ads Analytics Suite (Overview, Campaigns, AdSets, Creatives, Winning, Poor Performers, Audience, Places, Compare)
 ├── 3. Shopify Sales Analytics Suite (Overview, Orders, Products, Customers, Location, Compare)
 ├── 4. Attribution Tracking Module (Order-level traffic source mapping)
 ├── 5. Client Team Management (Client owner team member permissions)
 ├── 6. Admin User Management (Root Admin & Admin multi-tier RBAC management)
 └── 7. Integrations Center (Meta Ads, Shopify Store, Google Ads placeholder)
```

---

## Detailed Feature Matrix

| Feature | Associated Pages | Primary Backend APIs | DB Models | External Services | Required Permission | Status | Potential Problems |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Business Overview** | `/overview` | `GET /api/profile/kpi-preferences`, `GET /api/meta/analytics/overview`, `GET /api/shopify/overview` | `User` | Windsor.ai | `dashboard.view` | COMPLETE | Fires multiple parallel external API queries when both Meta & Shopify cards are visible. |
| **Meta Analytics** | `/meta/overview`, `/meta/campaigns`, `/meta/adsets`, `/meta/creatives`, `/meta/winning-creatives`, `/meta/poor-performers`, `/meta/audience`, `/meta/places`, `/meta/compare` | `GET /api/meta/analytics/:endpoint`, `GET /api/meta/campaigns/:id/details`, `GET /api/meta/compare` | `User` | Windsor.ai | `meta.overview`, `meta.campaigns`, etc. | COMPLETE | Real-time Windsor queries cause 2-4s page loading latency on wide date ranges. |
| **Shopify Analytics** | `/shopify/overview`, `/shopify/orders`, `/shopify/products`, `/shopify/customers`, `/shopify/location`, `/shopify/compare` | `GET /api/shopify/overview`, `GET /api/shopify/orders`, `GET /api/shopify/products`, `GET /api/shopify/customers`, `GET /api/shopify/location`, `GET /api/shopify/compare` | `User` | Windsor.ai | `shopify.overview`, `shopify.orders`, etc. | COMPLETE | Large order list responses without server-side database indexing. |
| **Attribution** | `/attribution` | `GET /api/attribution/overview`, `GET /api/attribution/orders` | `User` | Windsor.ai | `attribution.view` | COMPLETE | Relies on sample order data parsed via regex classifier when live tracking pixel is un-linked. |
| **Client Team Management** | `/team` | `GET /api/client/team`, `POST /api/client/team`, `PATCH /api/client/team/:id/permissions` | `User` | None | Client role | COMPLETE | Modals use inline state; potential stale state if permissions fail to save. |
| **Admin User Management** | `/admin/users` | `GET /api/admin/users/*`, `POST /api/admin/clients`, `PATCH /api/admin/users/:id/permissions` | `User`, `Organization`, `AdminAssignment`, `GlobalSettings` | None | `requireAdmin`, `requireRootAdmin` | COMPLETE | Large monolithic component (39.5 KB) handling all tabs in one file. |
| **Meta Integration** | `/integrations/meta`, `/welcome` | `GET /api/meta/accounts`, `POST /api/meta/accounts`, `PATCH /api/meta/accounts/active` | `User` | None | `meta.view` | COMPLETE | Deleting all accounts has no UI confirmation dialog. |
| **Shopify Integration**| `/integrations/shopify` | `GET /api/shopify/accounts`, `POST /api/shopify/accounts`, `PATCH /api/shopify/accounts/active` | `User` | None | `shopify.view` | COMPLETE | Minor duplicate PUT / PATCH endpoints defined in routes. |
| **Google Integration** | `/integrations/google` | None | None | None | Authenticated | EXPERIMENTAL | Static placeholder UI view; backend Google provider integration not yet implemented. |

---

## Feature Completeness Summary

- **Complete Production Features**: 8
- **Experimental / Placeholder Features**: 1 (`Google Integration`)
- **Broken / Abandoned Features**: 0
