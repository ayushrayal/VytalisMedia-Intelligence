# 17 - Deployment & Infrastructure Architecture

This document documents the deployment model, environment configuration, hosting setup, and single points of failure for Vytalis Intelligence.

---

## Hosting & Environment Architecture

```
                                [ Users (Web Browser) ]
                                           │
                                           ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ RENDER WEB SERVICE (https://vytalismedia-intelligence.onrender.com)                  │
│                                                                                     │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │ Express Node.js Server Process (server.js -> app.js)                          │  │
│  │                                                                               │  │
│  │  - Serves API Routes (/api/*)                                                 │  │
│  │  - Serves Static React Assets (Backend/Src/public/ built via Vite)            │  │
│  │  - React Router Fallback (sendFile index.html for non-API GET routes)         │  │
│  └──────────────────────────────────────┬────────────────────────────────────────┘  │
└─────────────────────────────────────────┼───────────────────────────────────────────┘
                                          │
                   ┌──────────────────────┼──────────────────────┐
                   ▼                      ▼                      ▼
        ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
        │  MongoDB Atlas   │    │   Redis Cloud    │    │  Windsor.ai API  │
        │ (Database Cloud) │    │  (Rate Limiter)  │    │ (Data Pipeline)  │
        └──────────────────┘    └──────────────────┘    └──────────────────┘
```

---

## Environment Configuration Inventory

| Variable Name | Purpose | Required in Prod? | Default / Notes |
| :--- | :--- | :---: | :--- |
| `PORT` | HTTP Server Listener Port | NO | Default: `5000` |
| `NODE_ENV` | Mode Identifier | YES | Set to `"production"` |
| `MONGODB_URI` | MongoDB Atlas Connection String | YES | `mongodb+srv://...` |
| `REDIS_URL` | Redis Cloud Connection String | YES | `redis://...` |
| `JWT_SECRET` | Secret Key for Signing Session JWTs | YES | Must be strong random string |
| `SYSTEM_ACCESS_CODE` | Code Required for Signup | YES | String |
| `ADMIN_UPGRADE_KEY` | Key for Role Upgrade Backdoor | YES (Remove) | Security risk endpoint key |
| `WINDSOR_API_KEY` | Windsor.ai API Authentication Key | YES | Connector access key |
| `WINDSOR_API_TIMEOUT` | Windsor Request Timeout (ms) | NO | Default: `15000` |
| `TRUST_PROXY` | Proxy Hop Configuration | NO | Default: `1` (Render Reverse Proxy) |

---

## Infrastructure Single Points of Failure (SPOF)

### 1. Single Application Node Instance
- **Risk**: The server runs as a single Node.js process. Process crashes (e.g. unhandled exception or memory limit) render the application temporarily unavailable until Render automatically restarts the process.
- **Recommendation**: Deploy with PM2 cluster mode or scale to multiple application instances on Render.

### 2. External Windsor.ai Third-Party Dependency
- **Risk**: All Meta Ads and Shopify analytics pages query Windsor.ai directly during user page requests. A Windsor outage causes platform-wide dashboard failures.
- **Recommendation**: Implement local database caching and background data sync workers to decouple user dashboard views from third-party API availability.
