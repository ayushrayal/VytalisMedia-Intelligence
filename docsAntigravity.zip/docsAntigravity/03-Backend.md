# 03 - Backend Audit

This document provides an exhaustive technical audit of the Vytalis Intelligence Express.js backend application.

---

## Express Setup & Request Execution Lifecycle

```
Incoming HTTP Request
      │
      ▼
Express Application (Backend/Src/app.js)
      │
      ├── Trust Proxy Configuration (Configured via TRUST_PROXY env)
      ├── Strict CORS Middleware (Whitelists explicit origins, allows .onrender.com & localhost)
      ├── Cookie Parser & JSON Parser
      │
      ▼
Route Router Matching (Backend/Src/routes/*.routes.js)
      │
      ▼
Middleware Chain:
 1. Rate Limiting Middleware (rate-limit.middleware.js)
 2. Authentication Middleware (protect in auth.middleware.js)
 3. Organization Isolation (requireOrganizationAccess in organization-auth.middleware.js)
 4. Effective Permission Check (requireEffectivePermission in auth.middleware.js)
      │
      ▼
Validator Execution (Joi schemas in Backend/Src/validators/*.validator.js)
      │
      ▼
Controller Execution (Backend/Src/controllers/*.controller.js)
      │
      ▼
Service Business Logic (Backend/Src/services/*.service.js)
      │
 ┌────┴────────────────────────┐
 ▼                             ▼
Adapter / Provider            MongoDB Database
(facebook.adapter.js)        (User, Organization, etc.)
 (windsor.provider.js)
      │                        │
      └────────────┬───────────┘
                   ▼
API Response Utility (api-response.util.js: sendSuccess / sendError)
                   │
                   ▼
Global Error Handler (error.middleware.js)
```

---

## Detailed Directory & Component Audit

### 1. Routes (`Backend/Src/routes/`)
- `auth.routes.js`: Exposes `/signup`, `/login`, `/refresh`, `/logout`, `/me`. Features dedicated strict IP rate limiters on public auth endpoints.
- `admin.routes.js`: User management endpoints. Enforces `protect` and `requireAdmin` globally. Requires specific RBAC permissions (`user_management.admins`, `user_management.clients`, `user_management.members`).
- `client-team.routes.js`: Client team management endpoints. Restricted to `requireClient`.
- `meta.routes.js`: Meta analytics endpoints (`/analytics/:endpoint`, `/campaigns/:id/details`, `/compare`, `/accounts`).
- `shopify.routes.js`: Shopify analytics endpoints (`/overview`, `/orders`, `/products`, `/customers`, `/location`, `/compare`, `/accounts`).
- `attribution.routes.js`: Attribution endpoints (`/overview`, `/orders`).
- `profile.routes.js`: User profile management, KPI card preferences, and role upgrade endpoint.

### 2. Middleware (`Backend/Src/middleware/`)
- `auth.middleware.js`:
  - `protect`: Extracts JWT from `access_token` cookie (or Bearer header fallback), verifies token, checks if user `status === "disabled"`, updates `lastActiveAt` throttled to 5 minutes.
  - `requireRootAdmin`: Verifies `user.role === "root_admin"` or `user.isRootAdmin === true`.
  - `requireAdmin`: Verifies `user.role` is `root_admin` or `admin`.
  - `requireClient`: Verifies `user.role === "client"`.
  - `requireEffectivePermission(permissionKey)`: Asynchronously calls `calculateEffectivePermission()`.
- `organization-auth.middleware.js`:
  - `requireOrganizationAccess`: Resolves user organization context based on role hierarchy. Validates target `organizationId` to prevent cross-tenant access.
- `rate-limit.middleware.js`:
  - Implements sliding window rate limiting backed by Redis `incrWithTtl()`. Includes `signupRateLimiter`, `loginRateLimiter`, and `apiRateLimiter`.
- `error.middleware.js`:
  - Global error middleware catching unhandled express errors, logging stack trace, returning standard JSON response `{ success: false, message: ... }`.

### 3. Controllers (`Backend/Src/controllers/`)
- `admin.controller.js` (39.6 KB, ~1000 lines): Manages creation, listing, status toggle, permission updates, and deletion of Admins, Clients, and Members.
- `auth.controller.js`: Handles signup, login (issuing HttpOnly JWT cookies), refresh, logout, and `/me`.
- `client-team.controller.js`: Handles Client team creation, member list, and permission assignment.
- `meta.controller.js`: Delegates Meta analytics queries to `meta-analytics.service.js`.
- `shopify.controller.js`: Delegates Shopify analytics queries to `shopify-data.service.js`.
- `attribution.controller.js`: Delegates attribution queries to `attribution.service.js`.
- `profile.controller.js`: User profile retrieval, KPI preferences updates, navigation preferences, and role upgrade handler.

### 4. Services (`Backend/Src/services/`)
- `meta-analytics.service.js` (23.0 KB): Transforms raw Facebook ad data into performance summaries (spend, ROAS, CPA, CTR, CPM, hook rate, hold rate) and date comparisons.
- `shopify-data.service.js` (13.5 KB): Calculates sales totals, gross/net sales, total orders, discounts, AOV, location breakdowns, and product rankings.
- `attribution.service.js` (16.4 KB): Aggregates UTM parameters, referrer data, and order IDs to build traffic source attribution models.
- `auth.service.js`: User creation logic, access token generation, and credential checking.

### 5. Adapters & Providers (`Backend/Src/adapters/` & `Backend/Src/providers/`)
- `facebook.adapter.js` (33.5 KB): Mappings between internal field names and Windsor Facebook connector parameters.
- `shopify.adapter.js` (2.6 KB): Mappings for Windsor Shopify connector parameters.
- `windsor.provider.js` (2.4 KB): Isolated HTTP client wrapping Axios requests to `https://api.windsor.ai`.

---

## Architectural Findings & Recommendations

### 1. Monolithic Admin Controller (`admin.controller.js`)
- **Severity**: MEDIUM
- **Location**: [`admin.controller.js`](file:///d:/VM%20Intelligence/Backend/Src/controllers/admin.controller.js)
- **Problem**: 39.6 KB file contains raw database mutations, audit log creation, and pagination logic inline.
- **Fix**: Split into dedicated service classes: `admin-user.service.js`, `admin-permission.service.js`, `global-settings.service.js`.

### 2. Privilege Escalation Endpoint (`profile.controller.js`)
- **Severity**: CRITICAL
- **Location**: [`profile.controller.js:24`](file:///d:/VM%20Intelligence/Backend/Src/controllers/profile.controller.js#L24)
- **Problem**: `upgradeRole` allows any authenticated account providing `ADMIN_UPGRADE_KEY` to turn into an `admin` or `root_admin`.
- **Why it matters**: Severe backdoor risk if key is leaked or brute-forced.
- **Fix**: Remove `upgradeRole` handler and route `POST /api/profile/upgrade-role`.

### 3. Lack of Circuit Breaker for External API Provider
- **Severity**: HIGH
- **Location**: [`windsor.provider.js`](file:///d:/VM%20Intelligence/Backend/Src/providers/windsor.provider.js)
- **Problem**: If Windsor.ai experiences downtime or latency spikes, backend worker threads wait up to 15 seconds per call, causing thread pool exhaustion.
- **Fix**: Implement circuit breaker pattern (e.g., using `opossum` package) with fallback error responses.
