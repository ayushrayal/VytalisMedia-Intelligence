# 19 - Complete API Audit Table

This document provides an exhaustive, row-by-row audit inventory of EVERY backend API route registered in the Express backend codebase.

---

## Backend API Inventory Table (63 Endpoints)

| Method | Endpoint | Purpose | Auth | Permission | Controller | Service | Ext API | DB Model | Used By Frontend | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/signup` | Register new user | Public | None | `authController.signup` | `auth.service.js` | None | `User` | `SignupPage.jsx` | ACTIVE |
| `POST` | `/api/auth/login` | Authenticate user | Public | None | `authController.login` | `auth.service.js` | None | `User` | `LoginPage.jsx` | ACTIVE |
| `POST` | `/api/auth/refresh` | Refresh JWT cookie | Cookie | None | `authController.refresh` | `auth.service.js` | None | `User` | `http.js` interceptor | ACTIVE |
| `POST` | `/api/auth/logout` | Revoke JWT cookie | None | None | `authController.logout` | None | None | None | `LogoutConfirmationModal.jsx` | ACTIVE |
| `GET` | `/api/auth/me` | Fetch active user state | JWT | Authenticated | `authController.getMe` | None | None | `User` | `router.jsx` restoreSession | ACTIVE |
| `GET` | `/api/admin/users/counts` | User summary metrics | JWT | `requireAdmin` | `adminController.getUserCounts` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `GET` | `/api/admin/users/admins` | List Admin accounts | JWT | `user_management.admins` | `adminController.getAllAdmins` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `POST` | `/api/admin/admins` | Create Admin account | JWT | `requireRootAdmin` | `adminController.createAdmin` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `GET` | `/api/admin/users/clients` | List Client accounts | JWT | `user_management.clients` | `adminController.getAllClients` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `POST` | `/api/admin/clients` | Create Client account | JWT | `user_management.clients` | `adminController.createClient` | None | None | `User`, `Organization` | `UserManagement.jsx` | ACTIVE |
| `POST` | `/api/admin/users` | Legacy Client creation | JWT | `user_management.clients` | `adminController.createClient` | None | None | `User`, `Organization` | None (Alias for `/clients`) | DUPLICATE |
| `GET` | `/api/admin/users/members` | List Member accounts | JWT | `user_management.members` | `adminController.getAllMembers` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `POST` | `/api/admin/members` | Create Member account | JWT | `user_management.members` | `adminController.createMember` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `PATCH` | `/api/admin/users/:userId/permissions` | Update user permissions | JWT | `user_management.members` | `adminController.updateUserPermissions` | None | None | `User` | `UserPermissionsModal.jsx` | ACTIVE |
| `PATCH` | `/api/admin/users/:userId/status` | Enable/disable user | JWT | `user_management.members` | `adminController.updateUserStatus` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `PATCH` | `/api/admin/users/:userId/role` | Change account role | JWT | `requireRootAdmin` | `adminController.updateUserRole` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `DELETE` | `/api/admin/users/:userId` | Delete user account | JWT | `user_management.members` | `adminController.deleteUser` | None | None | `User` | `UserManagement.jsx` | ACTIVE |
| `GET` | `/api/admin/global-settings` | Fetch system restrictions | JWT | `requireAdmin` | `adminController.getGlobalSettings` | None | None | `GlobalSettings` | `UserManagement.jsx` | ACTIVE |
| `PATCH` | `/api/admin/global-settings` | Toggle global restrictions | JWT | `requireRootAdmin` | `adminController.updateGlobalSettings` | None | None | `GlobalSettings` | `UserManagement.jsx` | ACTIVE |
| `POST` | `/api/admin/organizations/:organizationId/admins` | Assign Admin to Org | JWT | `requireRootAdmin` | `adminController.assignAdminToOrganization` | None | None | `AdminAssignment` | `UserManagement.jsx` | ACTIVE |
| `DELETE` | `/api/admin/organizations/:organizationId/admins/:adminId` | Unassign Admin | JWT | `requireRootAdmin` | `adminController.unassignAdminFromOrganization` | None | None | `AdminAssignment` | `UserManagement.jsx` | ACTIVE |
| `GET` | `/api/client/team` | List Client team members | JWT | `requireClient` | `clientTeamController.getClientTeamMembers` | None | None | `User` | `ClientTeamManagement.jsx` | ACTIVE |
| `POST` | `/api/client/team` | Add Client team member | JWT | `requireClient` | `clientTeamController.createClientTeamMember` | None | None | `User` | `ClientTeamManagement.jsx` | ACTIVE |
| `PATCH` | `/api/client/team/:memberId/permissions` | Update team member perms | JWT | `requireClient` | `clientTeamController.updateClientTeamMemberPermissions` | None | None | `User` | `UserPermissionsModal.jsx` | ACTIVE |
| `PATCH` | `/api/client/team/:memberId/status` | Enable/disable team member | JWT | `requireClient` | `clientTeamController.updateClientTeamMemberStatus` | None | None | `User` | `ClientTeamManagement.jsx` | ACTIVE |
| `DELETE` | `/api/client/team/:memberId` | Delete team member | JWT | `requireClient` | `clientTeamController.deleteClientTeamMember` | None | None | `User` | `ClientTeamManagement.jsx` | ACTIVE |
| `GET` | `/api/meta/preferences/creative-card` | Get creative card KPI preferences | JWT | `meta.creatives` | `metaController.getCreativeCardPreferences` | None | None | `User` | `Creatives.jsx` | ACTIVE |
| `PUT` | `/api/meta/preferences/creative-card` | Update creative card KPI preferences | JWT | `meta.creatives` | `metaController.updateCreativeCardPreferences` | None | None | `User` | `Creatives.jsx` | ACTIVE |
| `GET` | `/api/meta/campaigns/:campaignId/details` | Fetch Meta campaign details | JWT | `meta.campaigns` | `metaController.getCampaignDetails` | `meta-analytics.service.js` | Windsor | None | `Campaigns.jsx` | ACTIVE |
| `GET` | `/api/meta/campaigns/:campaignId/breakdowns` | Campaign breakdown demographics | JWT | `meta.campaigns` | `metaController.getCampaignBreakdowns` | `meta-analytics.service.js` | Windsor | None | `Campaigns.jsx` | ACTIVE |
| `GET` | `/api/meta/adsets/:adsetId/breakdowns` | AdSet breakdown demographics | JWT | `meta.adsets` | `metaController.getAdSetBreakdowns` | `meta-analytics.service.js` | Windsor | None | `AdSets.jsx` | ACTIVE |
| `GET` | `/api/meta/ads/:adId/breakdowns` | Ad creative breakdowns | JWT | `meta.creatives` | `metaController.getAdBreakdowns` | `meta-analytics.service.js` | Windsor | None | `Creatives.jsx` | ACTIVE |
| `GET` | `/api/meta/compare` | Meta period comparison | JWT | `meta.compare` | `metaController.getMetaComparison` | `meta-analytics.service.js` | Windsor | None | `MetaCompare.jsx` | ACTIVE |
| `GET` | `/api/meta/analytics/:endpoint` | Meta analytics overview/tabs | JWT | Dynamic (`meta.overview`, etc.) | `metaController.getAnalyticsData` | `meta-analytics.service.js` | Windsor | None | `MetaOverview.jsx`, `Campaigns.jsx`, etc. | ACTIVE |
| `POST` | `/api/meta/accounts` | Add Meta ad account | JWT | `meta.view` | `metaController.addAccount` | None | None | `User` | `MetaAccounts.jsx`, `Welcome.jsx` | ACTIVE |
| `GET` | `/api/meta/accounts` | List Meta ad accounts | JWT | `meta.view` | `metaController.getAllAccounts` | None | None | `User` | `MetaAccounts.jsx` | ACTIVE |
| `DELETE` | `/api/meta/accounts` | Clear all Meta accounts | JWT | `meta.view` | `metaController.deleteAllAccounts` | None | None | `User` | None | UNUSED |
| `PATCH` | `/api/meta/accounts/active` | Select active Meta account | JWT | `meta.view` | `metaController.setActiveAccount` | None | None | `User` | `MetaAccounts.jsx`, Header | ACTIVE |
| `GET` | `/api/meta/accounts/:accountId` | Fetch single Meta account | JWT | `meta.view` | `metaController.getAccountById` | None | None | `User` | None | UNUSED |
| `PATCH` | `/api/meta/accounts/:accountId` | Update Meta account info | JWT | `meta.view` | `metaController.updateAccount` | None | None | `User` | `MetaAccounts.jsx` | ACTIVE |
| `DELETE` | `/api/meta/accounts/:accountId` | Delete Meta account | JWT | `meta.view` | `metaController.deleteAccount` | None | None | `User` | `MetaAccounts.jsx` | ACTIVE |
| `GET` | `/api/shopify/compare` | Shopify period comparison | JWT | `shopify.compare` | `shopifyController.getShopifyComparison` | `shopify-data.service.js` | Windsor | None | `ShopifyCompare.jsx` | ACTIVE |
| `GET` | `/api/shopify/overview` | Store overview analytics | JWT | `shopify.overview` | `shopifyController.getOverview` | `shopify-data.service.js` | Windsor | None | `ShopifyOverview.jsx`, `DashboardOverview.jsx` | ACTIVE |
| `GET` | `/api/shopify/orders` | Store sales orders list | JWT | `shopify.orders` | `shopifyController.getOrders` | `shopify-data.service.js` | Windsor | None | `ShopifyOrders.jsx` | ACTIVE |
| `GET` | `/api/shopify/products` | Product inventory sales | JWT | `shopify.products` | `shopifyController.getProducts` | `shopify-data.service.js` | Windsor | None | `ShopifyProducts.jsx` | ACTIVE |
| `GET` | `/api/shopify/customers` | Customer cohort analytics | JWT | `shopify.customers` | `shopifyController.getCustomers` | `shopify-data.service.js` | Windsor | None | `ShopifyCustomers.jsx` | ACTIVE |
| `GET` | `/api/shopify/location` | Geographic sales breakdown | JWT | `shopify.location` | `shopifyController.getLocation` | `shopify-data.service.js` | Windsor | None | `ShopifyLocation.jsx` | ACTIVE |
| `POST` | `/api/shopify/accounts` | Add Shopify store connection | JWT | `shopify.view` | `shopifyController.addAccount` | None | None | `User` | `ShopifyAccounts.jsx` | ACTIVE |
| `GET` | `/api/shopify/accounts` | List Shopify store accounts | JWT | `shopify.view` | `shopifyController.getAllAccounts` | None | None | `User` | `ShopifyAccounts.jsx` | ACTIVE |
| `PATCH` | `/api/shopify/accounts/active` | Select active Shopify store | JWT | `shopify.view` | `shopifyController.setActiveAccount` | None | None | `User` | `ShopifyAccounts.jsx` | ACTIVE |
| `PUT` | `/api/shopify/accounts/active` | Alias select active store | JWT | `shopify.view` | `shopifyController.setActiveAccount` | None | None | `User` | None | DUPLICATE |
| `GET` | `/api/shopify/accounts/:id` | Fetch single store account | JWT | `shopify.view` | `shopifyController.getAccountById` | None | None | `User` | None | UNUSED |
| `PUT` | `/api/shopify/accounts/:id` | Update store connection | JWT | `shopify.view` | `shopifyController.updateAccount` | None | None | `User` | `ShopifyAccounts.jsx` | ACTIVE |
| `PATCH` | `/api/shopify/accounts/:id` | Alias update store connection | JWT | `shopify.view` | `shopifyController.updateAccount` | None | None | `User` | None | DUPLICATE |
| `DELETE` | `/api/shopify/accounts/:id` | Disconnect store connection | JWT | `shopify.view` | `shopifyController.deleteAccount` | None | None | `User` | `ShopifyAccounts.jsx` | ACTIVE |
| `GET` | `/api/attribution/overview` | Attribution summary totals | JWT | `attribution.view` | `attributionController.getOverview` | `attribution.service.js` | None | None | `AttributionOverview.jsx` | ACTIVE |
| `GET` | `/api/attribution/orders` | Attribution order records | JWT | `attribution.view` | `attributionController.getOrders` | `attribution.service.js` | None | None | `AttributionOverview.jsx` | ACTIVE |
| `GET` | `/api/profile` | Get current user profile | JWT | Authenticated | `profileController.getProfile` | None | None | `User` | `Profile.jsx` | ACTIVE |
| `POST` | `/api/profile/upgrade-role` | Upgrade account role to Admin | JWT | Authenticated | `profileController.upgradeRole` | None | None | `User` | `Profile.jsx` | SUSPICIOUS |
| `GET` | `/api/profile/kpi-preferences` | Get KPI card preferences | JWT | Authenticated | `profileController.getKpiPreferences` | None | None | `User` | `DashboardOverview.jsx` | ACTIVE |
| `PUT` | `/api/profile/kpi-preferences` | Update KPI card preferences | JWT | Authenticated | `profileController.updateKpiPreferences` | None | None | `User` | `Profile.jsx` | ACTIVE |
| `PUT` | `/api/profile/navigation-preferences` | Update navigation preferences | JWT | Authenticated | `profileController.updateNavigationPreferences` | None | None | `User` | `DashboardLayout.jsx` | ACTIVE |
| `GET` | `/api/health` | Service health check | Public | None | Inline handler | None | None | None | Uptime Check | ACTIVE |

---

## Audit Summary Statistics

- **Total API Routes Defined**: 63
- **Active Endpoints**: 54
- **Duplicate Endpoint Aliases**: 4 (`POST /api/admin/users`, `PUT /api/shopify/accounts/active`, `PATCH /api/shopify/accounts/:id`)
- **Unused Endpoints**: 4 (`DELETE /api/meta/accounts`, `GET /api/meta/accounts/:accountId`, `GET /api/shopify/accounts/:id`)
- **Suspicious Backdoor Endpoints**: 1 (`POST /api/profile/upgrade-role`)
