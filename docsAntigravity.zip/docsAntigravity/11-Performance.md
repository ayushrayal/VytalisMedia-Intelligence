# 11 - Performance Audit & Optimization

This document identifies performance bottlenecks across the frontend, backend APIs, database queries, and external network interactions.

---

## Key Performance Bottlenecks & Fixes

### 1. Un-cached Real-time External API Fetching
- **Location**: [`Backend/Src/providers/windsor.provider.js`](file:///d:/VM%20Intelligence/Backend/Src/providers/windsor.provider.js#L24)
- **Why Slow**: Requests to `api.windsor.ai` take 1.5s - 4.0s to execute depending on date range width.
- **Impact**: High page loading latency every time a user opens or switches tabs.
- **Fix**: Cache transformed Windsor payloads in Redis with a 15-minute TTL (`cache.util.js`).
- **Priority**: P0

### 2. Missing Route-Based Code-Splitting in React Frontend
- **Location**: [`Frontend/src/app/router.jsx`](file:///d:/VM%20Intelligence/Frontend/src/app/router.jsx#L15)
- **Why Slow**: All 26 page components are imported statically at the top of `router.jsx`.
- **Impact**: Increases initial JavaScript bundle size, delaying initial page render time.
- **Fix**: Wrap page imports in `React.lazy()` and `React.Suspense` for dynamic code-splitting.
- **Priority**: P1

### 3. Oversized Breakdown Payloads
- **Location**: [`Backend/Src/controllers/meta.controller.js`](file:///d:/VM%20Intelligence/Backend/Src/controllers/meta.controller.js)
- **Why Slow**: Breakdown endpoints (`/campaigns/:id/breakdowns`, `/ads/:id/breakdowns`) return full country, age, and placement data arrays for all items simultaneously.
- **Impact**: Transmits 500KB+ payloads over HTTP when the user only inspects one modal.
- **Fix**: Add query parameter filters to fetch breakdowns only for the selected item ID.
- **Priority**: P1

### 4. Unindexed MongoDB Audit Log Queries
- **Location**: [`Backend/Src/models/audit-log.model.js`](file:///d:/VM%20Intelligence/Backend/Src/models/audit-log.model.js)
- **Why Slow**: Filtering audit logs by organization and action type causes full collection scans.
- **Fix**: Add compound index `{ organizationId: 1, action: 1, createdAt: -1 }`.
- **Priority**: P2
