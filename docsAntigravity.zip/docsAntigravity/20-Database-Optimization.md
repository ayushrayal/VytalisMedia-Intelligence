# 20 - Database Optimization Plan

This document outlines targeted optimization plans to make MongoDB faster, reduce query latency, and eliminate full collection scans.

---

## Current Query Bottlenecks

### 1. Unindexed Audit Log Queries
- **Current Behavior**: When fetching audit logs for a specific organization or filtering by administrative action, MongoDB performs a scan over `auditlogs`.
- **Impact**: Increased query response time as the audit log grows.
- **Recommended Index**:
  ```js
  auditLogSchema.index({ organizationId: 1, action: 1, createdAt: -1 });
  ```
- **Expected Benefit**: Query execution time drops from O(N) to O(log N).

### 2. Full User Field Population During Permission Checks
- **Current Behavior**: `calculateBatchEffectivePermissions` fetches complete `User` documents without field projections.
- **Impact**: Transfers unnecessary fields (e.g. large `preferences` objects, video card settings, integration arrays) over the network.
- **Recommended Fix**: Add explicit field projections:
  ```js
  User.find({ _id: { $in: userIds } })
    .select("_id name email role status organizationId assignedClientId assignedPermissions isRootAdmin")
    .lean();
  ```
- **Expected Benefit**: 60-70% reduction in database payload transfer size.

### 3. Missing Pagination on User Management Endpoints
- **Current Behavior**: `getAllClients`, `getAllAdmins`, and `getAllMembers` in [`admin.controller.js`](file:///d:/VM%20Intelligence/Backend/Src/controllers/admin.controller.js#L110) fetch ALL matching users in a single unpaginated query (`User.find(filter)`).
- **Impact**: Under high user counts (e.g. 5,000+ accounts), loading `/admin/users` will cause server memory spikes and response slowdowns.
- **Recommended Fix**: Implement standard limit/offset pagination parameters (`page=1&limit=25`).

---

## Recommended Index Additions Summary

| Collection | Target Fields | Type | Rationale & Expected Impact | Priority |
| :--- | :--- | :--- | :--- | :---: |
| `auditlogs` | `{ organizationId: 1, action: 1, createdAt: -1 }` | Compound | Fast filtering of administrative logs by organization and action type. | P1 |
| `users` | `{ email: 1, status: 1 }` | Compound | Fast user authentication lookup checking both email and disabled status. | P1 |
| `users` | `{ organizationId: 1, role: 1, assignedClientId: 1 }` | Compound | Optimizes batch effective permission calculation context lookups. | P2 |

---

## Connection Pooling & Mongoose Configuration

Current connection options in `Backend/Src/config/db.js`:
```js
await mongoose.connect(process.env.MONGODB_URI, {
  maxPoolSize: 10, // Recommended to scale to 50 for high concurrency
  serverSelectionTimeoutMS: 5000,
  socketTimeoutMS: 45000,
});
```

### Recommendation
For medium-to-high load environments, increase `maxPoolSize` to `50` in production to prevent connection queueing during concurrent analytics requests.
