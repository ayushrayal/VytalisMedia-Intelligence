# 13 - Known Bugs & Code Risks

This document catalogs code bugs, suspicious implementations, and operational risks discovered during the audit.

---

## Catalog of Identified Bugs & Code Risks

### BUG-01: Role Upgrade Privilege Backdoor
- **ID**: `BUG-01`
- **Severity**: **CRITICAL**
- **File**: [`Backend/Src/controllers/profile.controller.js:24`](file:///d:/VM%20Intelligence/Backend/Src/controllers/profile.controller.js#L24)
- **Function**: `upgradeRole`
- **Problem**: Accepts a secret string parameter `key` to grant `admin` or `isRootAdmin` privileges to any logged-in user.
- **Why it Happens**: Created as a shortcut endpoint for local development or initial bootstrap.
- **Impact**: Attacker who guesses or discovers `ADMIN_UPGRADE_KEY` gains full system ownership.
- **Recommended Fix**: Delete the `upgradeRole` function and remove `POST /api/profile/upgrade-role` route.
- **Testing Required**: Attempt POST request to `/api/profile/upgrade-role` and verify HTTP 404 response.

---

### BUG-02: Hardcoded DNS Server Overrides
- **ID**: `BUG-02`
- **Severity**: **HIGH**
- **File**: [`Backend/server.js:1-2`](file:///d:/VM%20Intelligence/Backend/server.js#L1-L2)
- **Function**: Server Bootstrap
- **Problem**: Explicitly overrides system DNS servers with Google Public DNS:
  ```js
  const dns = require('dns');
  dns.setServers(['8.8.8.8', '8.8.4.4']);
  ```
- **Why it Happens**: Workaround for local environment DNS lookup issues.
- **Impact**: Bypasses local network/Docker internal DNS resolution, breaking internal MongoDB atlas VPC peering or private corporate DNS networks.
- **Recommended Fix**: Wrap DNS override in a conditional environment check (`if (process.env.CUSTOM_DNS) ...`).
- **Testing Required**: Verify backend database connectivity in isolated containerized environments.

---

### BUG-03: Absence of External API Circuit Breaker
- **ID**: `BUG-03`
- **Severity**: **HIGH**
- **File**: [`Backend/Src/providers/windsor.provider.js:44`](file:///d:/VM%20Intelligence/Backend/Src/providers/windsor.provider.js#L44)
- **Function**: `fetchData`
- **Problem**: Axios requests wait up to 15,000ms (15s) per request without circuit breaker protections.
- **Why it Happens**: Default timeout value lacks failure threshold tracking.
- **Impact**: During external provider outages, Express backend worker threads block until timeouts expire, leading to thread pool exhaustion.
- **Recommended Fix**: Integrate `opossum` circuit breaker to immediately fail fast after 5 consecutive provider errors.
- **Testing Required**: Simulate 502/504 external responses and verify rapid fallback response (<100ms).

---

### BUG-04: Duplicate Route Endpoints
- **ID**: `BUG-04`
- **Severity**: **MEDIUM**
- **File**: [`Backend/Src/routes/admin.routes.js:24`](file:///d:/VM%20Intelligence/Backend/Src/routes/admin.routes.js#L24), `shopify.routes.js:96`
- **Problem**: Multiple URL paths point to identical controller handlers (`POST /api/admin/users` & `POST /api/admin/clients`; `PUT /api/shopify/accounts/active` & `PATCH /api/shopify/accounts/active`).
- **Why it Happens**: Left behind during backward compatibility migrations.
- **Impact**: Increases route audit complexity and API documentation confusion.
- **Recommended Fix**: Deprecate legacy aliases and keep standardized canonical endpoints.

---

### BUG-05: MetricCard Component Duplication
- **ID**: `BUG-05`
- **Severity**: **LOW**
- **File**: `Frontend/src/components/ui/MetricCard.jsx` vs `Frontend/src/components/shared/MetricCard.jsx`
- **Problem**: Two active implementations of `MetricCard` exist in component directories.
- **Impact**: Maintenance confusion when styling metric cards across different pages.
- **Recommended Fix**: Delete `components/shared/MetricCard.jsx` and update imports to `components/ui/MetricCard.jsx`.
