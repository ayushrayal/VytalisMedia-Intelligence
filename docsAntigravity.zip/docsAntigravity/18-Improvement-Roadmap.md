# 18 - Technical Improvement Roadmap

This document outlines a phased, prioritized engineering roadmap to enhance security, performance, scalability, and code quality in Vytalis Intelligence.

---

## Priorities & Difficulty Matrix

| Priority | Task Description | Estimated Effort | Risk | Expected Benefit |
| :--- | :--- | :---: | :---: | :--- |
| **P0** | **Decommission `/api/profile/upgrade-role`** | 1 Hour | Low | Eliminates critical backdoor privilege escalation vulnerability. |
| **P0** | **Fix Hardcoded DNS Servers in `server.js`** | 30 Mins | Low | Prevents connection breaks in VPC / container environments. |
| **P1** | **Implement Redis Caching for Windsor Calls** | 1 Day | Low | Reduces dashboard load times from 3-4s down to <100ms. |
| **P1** | **Add Database Indexes (`auditlogs`, `users`)** | 2 Hours | Low | Prevents full collection scans on administrative audit logs. |
| **P1** | **Refactor `admin.controller.js`** | 2 Days | Medium | Improves maintainability by breaking up 1000-line controller. |
| **P2** | **Move Loose Test Files to `Backend/test/`** | 1 Hour | Low | Cleans up source folder and separates production code. |
| **P2** | **Setup Automated Jest / Vitest Test Runner**| 3 Days | Low | Enables CI/CD regression testing. |
| **P3** | **Deduplicate `MetricCard.jsx` UI Component** | 2 Hours | Low | Ensures consistent design system rendering across pages. |

---

## Phased Implementation Roadmap

```
PHASE 1: Security & Critical Fixes (Days 1 - 3)
 ├── 1. Delete POST /api/profile/upgrade-role backdoor endpoint.
 ├── 2. Make DNS server override conditional in server.js.
 └── 3. Implement single-use invite tokens for signup.

PHASE 2: Performance & Caching (Days 4 - 10)
 ├── 1. Implement 15-minute Redis response caching for Windsor API queries.
 ├── 2. Add composite index on auditlogs { organizationId: 1, action: 1, createdAt: -1 }.
 └── 3. Add pagination (limit/offset) to user management list endpoints.

PHASE 3: Code Architecture Cleanup (Days 11 - 18)
 ├── 1. Split admin.controller.js into modular services.
 ├── 2. Relocate loose test-*.js scripts from Backend/Src/ to Backend/test/.
 └── 3. Consolidate components/shared/MetricCard.jsx into components/ui/MetricCard.jsx.

PHASE 4: Scalability & Resilience (Days 19 - 25)
 ├── 1. Implement BullMQ background sync workers for analytics pre-fetching.
 ├── 2. Add Opossum circuit breaker around windsor.provider.js.
 └── 3. Scale Mongoose maxPoolSize to 50 connections.

PHASE 5: Developer Experience & CI/CD (Days 26 - 30)
 ├── 1. Configure Vitest / React Testing Library for frontend component tests.
 ├── 2. Add React.lazy route-based code splitting in router.jsx.
 └── 3. Setup GitHub Actions CI pipeline running npm test on pull requests.
```
