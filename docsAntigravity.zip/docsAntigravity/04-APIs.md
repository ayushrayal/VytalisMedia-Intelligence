# 04 - API Architecture & Design Guidelines

This document outlines the API design standards, authentication mechanisms, error handling conventions, and response structures used across Vytalis Intelligence.

---

## API Protocol & Conventions

### Base URL & Formatting
- **Base Endpoint Path**: `/api/`
- **Data Format**: `application/json`
- **Date Formatting**: ISO 8601 strings (`YYYY-MM-DD` or `YYYY-MM-DDTHH:mm:ss.sssZ`).

---

## Standardized JSON Response Structure

All API endpoints return JSON formatted via `api-response.util.js`:

### Success Response (`sendSuccess`)
```json
{
  "success": true,
  "message": "Campaigns analytics retrieved successfully.",
  "data": {
    "summary": {
      "spend": 14500.50,
      "roas": 3.42,
      "cpa": 24.15
    },
    "campaigns": []
  }
}
```

### Error Response (`sendError`)
```json
{
  "success": false,
  "message": "Your account does not have permission to access this feature.",
  "error": {
    "permissionKey": "meta.campaigns",
    "lockReason": "disabled_by_admin"
  }
}
```

---

## Authentication & Credentials Transport
1. **Primary Authentication**: HttpOnly, SameSite cookie named `access_token` containing a signed JSON Web Token (JWT).
2. **Fallback Authorization**: `Authorization: Bearer <JWT_TOKEN>` header for API clients without cookie support.
3. **Session Rejection**: HTTP 401 response issued when token is invalid, expired, or user account is disabled.

---

## Multi-Tenant Organization Context Header
For multi-tenant requests, clients can explicitly target an Organization by specifying:
- Query string parameter: `?organizationId=64aef...`
- Request body property: `{ "organizationId": "64aef..." }`

If omitted, `organization-auth.middleware.js` automatically resolves the user's assigned organization context from MongoDB (`user.organizationId` or `user.assignedClientId`).

---

## Rate Limiting & Throttling
- **Authentication Routes (`/api/auth/*`)**:
  - Signup: 5 attempts per 15 minutes per IP.
  - Login: 5 attempts per 15 minutes per IP.
- **General API Routes (`/api/*`)**:
  - Default limiter: 100 requests per 1-minute sliding window per IP/User.
- **Backend Implementation**: Powered by Redis sliding-window counter (`incrWithTtl()`).

---

## High-Level Category Overview

| Category | Endpoint Prefix | Purpose | Key Permissions |
| :--- | :--- | :--- | :--- |
| **Authentication** | `/api/auth` | User login, signup, token refresh, logout, session state. | Public / Authenticated |
| **Admin Management** | `/api/admin` | Role management, client/admin creation, permissions. | `requireAdmin`, `requireRootAdmin` |
| **Client Team** | `/api/client/team` | Team member creation & permission assignments. | `requireClient` |
| **Meta Analytics** | `/api/meta` | Ad spend, ROAS, CPA, hook/hold rates, breakdowns. | `meta.view`, `meta.campaigns`, etc. |
| **Shopify Analytics** | `/api/shopify` | Sales, orders, products, customers, location. | `shopify.view`, `shopify.orders`, etc. |
| **Attribution** | `/api/attribution` | Traffic channel mapping & order attribution. | `attribution.view` |
| **Profile** | `/api/profile` | Personal preferences, KPI card choices, navigation. | Authenticated |
