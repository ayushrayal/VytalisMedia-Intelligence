# 14 - Dead Code & Repository Cleanup

This document lists unused files, orphaned components, dead routes, and loose test scripts recommended for cleanup.

---

## 1. Loose Test Scripts in Source Folder (`Backend/Src/`)

### Identified Loose Files
- [`test-ad-breakdowns-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-ad-breakdowns-suite.js) (3.8 KB)
- [`test-admin-global-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-admin-global-suite.js) (2.0 KB)
- [`test-adset-breakdowns-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-adset-breakdowns-suite.js) (3.2 KB)
- [`test-campaign-breakdowns-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-campaign-breakdowns-suite.js) (4.5 KB)
- [`test-client-team-management-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-client-team-management-suite.js) (11.9 KB)
- [`test-final-rbac-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-final-rbac-suite.js) (4.5 KB)
- [`test-member-integration-resolution.js`](file:///d:/VM%20Intelligence/Backend/Src/test-member-integration-resolution.js) (5.9 KB)
- [`test-mongodb-source-of-truth-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-mongodb-source-of-truth-suite.js) (11.3 KB)
- [`test-redis-cache-miss-permission-sequence.js`](file:///d:/VM%20Intelligence/Backend/Src/test-redis-cache-miss-permission-sequence.js) (6.2 KB)
- [`test-root-admin-hierarchy-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-root-admin-hierarchy-suite.js) (11.1 KB)
- [`test-stale-permission-overwrite-suite.js`](file:///d:/VM%20Intelligence/Backend/Src/test-stale-permission-overwrite-suite.js) (16.0 KB)
- [`verify-member-creation-and-authority-ceiling.js`](file:///d:/VM%20Intelligence/Backend/Src/verify-member-creation-and-authority-ceiling.js) (3.3 KB)
- Scratch folder: `Backend/Src/scratch/`

### Audit Evidence & Analysis
- **Status**: UNUSED IN PRODUCTION
- **Confidence**: 100%
- **Why it Matters**: 12 loose test files (totaling 83.7 KB) live directly inside `Backend/Src/` alongside production source code. None of these files are imported by `app.js` or `server.js`.
- **Safe Cleanup Method**: Move all `test-*.js` files into `Backend/test/` directory to keep `Backend/Src/` clean.

---

## 2. Duplicate & Unused UI Components

### Identified File
- `Frontend/src/components/shared/MetricCard.jsx` (1.4 KB)
- **Status**: DUPLICATE
- **Confidence**: High
- **Evidence**: `Frontend/src/components/ui/MetricCard.jsx` is the primary metric card component consumed across all dashboard pages.
- **Safe Cleanup Method**: Replace references in shared components with `components/ui/MetricCard.jsx`, then delete `components/shared/MetricCard.jsx`.

---

## 3. Unused API Routes

### Identified Routes
1. `DELETE /api/meta/accounts` ([`meta.routes.js:139`](file:///d:/VM%20Intelligence/Backend/Src/routes/meta.routes.js#L139))
2. `GET /api/meta/accounts/:accountId` ([`meta.routes.js:146`](file:///d:/VM%20Intelligence/Backend/Src/routes/meta.routes.js#L146))
3. `GET /api/shopify/accounts/:id` ([`shopify.routes.js:97`](file:///d:/VM%20Intelligence/Backend/Src/routes/shopify.routes.js#L97))

### Audit Evidence & Analysis
- **Status**: UNUSED BY FRONTEND
- **Confidence**: High
- **Evidence**: Code search confirms no frontend page calls these specific endpoints.
- **Safe Cleanup Method**: Deprecate or remove during future API refactoring.
