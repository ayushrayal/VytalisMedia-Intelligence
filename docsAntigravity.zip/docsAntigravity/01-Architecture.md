# 01 - System Architecture

This document explains how data flows through Vytalis Intelligence, from the user's browser down to MongoDB, Redis, and the external Windsor.ai API provider.

---

## Complete Request & Data Flow Diagram

```
[ User Browser ]
       │
       ▼
┌────────────────────────────────────────────────────────┐
│ FRONTEND LAYER (React 19 + Vite)                       │
│  - Router: Frontend/src/app/router.jsx                 │
│  - Features: Frontend/src/features/{meta,shopify,etc}  │
│  - HTTP Client: Frontend/src/lib/http.js               │
└──────────────────────────┬─────────────────────────────┘
                           │ HTTP REST (JSON / HttpOnly Cookie Credentials)
                           ▼
┌────────────────────────────────────────────────────────┐
│ BACKEND SERVER (Node.js + Express v5)                  │
│  - Entry Point: Backend/server.js -> Backend/Src/app.js │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│ MIDDLEWARE LAYER                                       │
│  1. CORS (app.js)                                      │
│  2. Rate Limiter (rate-limit.middleware.js)            │
│  3. JWT Auth Guard (protect in auth.middleware.js)     │
│  4. Organization Access Guard                          │
│     (requireOrganizationAccess)                         │
│  5. RBAC Permission Guard                              │
│     (requireEffectivePermission)                        │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│ CONTROLLER LAYER (Backend/Src/controllers/)            │
│  - Extracts query params, body, and req.user / req.org │
│  - Validates input schemas (Joi validators)            │
│  - Invokes appropriate service methods                 │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│ SERVICE LAYER (Backend/Src/services/)                  │
│  - Business calculations (ROAS, CPA, AOV, Hook/Hold)   │
│  - Date range normalizations & comparisons             │
│  - Permission state evaluations                        │
└──────────────────────────┬─────────────────────────────┘
                           │
             ┌─────────────┴─────────────┐
             ▼                           ▼
┌───────────────────────────┐ ┌───────────────────────────┐
│ MONGODB / MONGOOSE        │ │ ADAPTER & PROVIDER LAYER  │
│ - User.model.js           │ │ - facebook.adapter.js     │
│ - Organization.model.js   │ │ - shopify.adapter.js      │
│ - AdminAssignment.model.js│ │ - attribution.adapter.js  │
│ - GlobalSettings.model.js │ │ - windsor.provider.js     │
└────────────┬──────────────┘ └─────────────┬─────────────┘
             │                              │
             ▼                              ▼
      [ MongoDB Database ]          [ Windsor.ai REST API ]
```

---

## Detailed Layer Breakdown

### Layer 1: Browser & React Frontend
- **Role**: Renders UI, handles routing, stores client state, and dispatches HTTP requests.
- **Key Location**: `Frontend/src/`
- **Key Files**:
  - `main.jsx` (Application bootstrap)
  - `app/router.jsx` (Client-side route definitions, route guards)
  - `lib/http.js` (Configured Axios client instance)
- **Key Behavior**: `http.js` sets `withCredentials: true` so the browser sends `access_token` cookies with every request. It also catches HTTP 401 responses and dispatches a global window event `vytalis:auth-expired` to automatically clear session state and redirect to `/login`.

### Layer 2: API Client (`http.js`)
- **Role**: Standardized HTTP client for all API interactions.
- **Key Location**: `Frontend/src/lib/http.js`
- **Behavior**: Uses environment variable `VITE_API_URL` (defaulting to `/api`). Includes request/response interceptors to format server error responses into predictable JavaScript Error objects.

### Layer 3: Backend Routes & Express Application
- **Role**: Defines REST endpoints and binds URL paths to middleware and controller functions.
- **Key Location**: `Backend/server.js`, `Backend/Src/app.js`, `Backend/Src/routes/`
- **Key Files**:
  - `server.js` (Server startup, database connection, RBAC migration trigger, Redis connection)
  - `app.js` (Express configuration, CORS headers, global error middleware)
  - `routes/auth.routes.js` (Authentication endpoints)
  - `routes/meta.routes.js` (Meta Ads endpoints)
  - `routes/shopify.routes.js` (Shopify endpoints)
  - `routes/admin.routes.js` (User management endpoints)
  - `routes/client-team.routes.js` (Client team management endpoints)

### Layer 4: Middleware Layer
- **Role**: Enforces security, rate-limiting, authentication, multi-tenant isolation, and RBAC authorization.
- **Key Location**: `Backend/Src/middleware/`
- **Key Functions**:
  - `protect` ([`auth.middleware.js`](file:///d:/VM%20Intelligence/Backend/Src/middleware/auth.middleware.js#L11)): Verifies JWT token from HttpOnly cookie or Bearer header, attaches `req.user`.
  - `requireOrganizationAccess` ([`organization-auth.middleware.js`](file:///d:/VM%20Intelligence/Backend/Src/middleware/organization-auth.middleware.js#L33)): Enforces multi-tenant data boundaries. Ensures Client/Member accounts can only access data belonging to their assigned Organization.
  - `requireEffectivePermission` ([`auth.middleware.js`](file:///d:/VM%20Intelligence/Backend/Src/middleware/auth.middleware.js#L95)): Evaluates effective permission rules using `calculateEffectivePermission()`.

### Layer 5: Controller Layer
- **Role**: Handles HTTP request parsing, validator execution, and HTTP response rendering.
- **Key Location**: `Backend/Src/controllers/`
- **Key Files**:
  - `meta.controller.js` (Meta analytics API handlers)
  - `shopify.controller.js` (Shopify analytics API handlers)
  - `admin.controller.js` (Admin user management handlers)
  - `client-team.controller.js` (Client team management handlers)

### Layer 6: Service Layer
- **Role**: Core business logic, data calculations, date range comparison math, and permission resolution.
- **Key Location**: `Backend/Src/services/`
- **Key Files**:
  - `meta-analytics.service.js` (Meta metric calculations: ROAS, CPA, CTR, CPM, Hook/Hold rates)
  - `shopify-data.service.js` (Shopify metric calculations: Sales, Orders, AOV, Customers)
  - `attribution.service.js` (Order-level traffic attribution matching)

### Layer 7: Adapter & Provider Layer
- **Role**: Interfaces with external APIs and normalizes raw external responses.
- **Key Location**: `Backend/Src/adapters/`, `Backend/Src/providers/`
- **Key Files**:
  - `facebook.adapter.js` (Transforms raw Windsor Meta API fields into normalized internal schema)
  - `shopify.adapter.js` (Transforms raw Windsor Shopify API fields)
  - `windsor.provider.js` (Executes HTTP requests to `api.windsor.ai` via Axios with configurable timeouts)

### Layer 8: Database & Cache Layer
- **Role**: Persistent data storage and volatile rate-limiting / cache storage.
- **Key Location**: MongoDB (via Mongoose), Redis
- **Key Files**:
  - `config/db.js` (MongoDB connection setup)
  - `utils/cache.util.js` (Redis client wrapper providing atomic `get`, `set`, `getDel`, `incrWithTtl` operations)

---

## Architectural Strengths & Known Weaknesses

### Strengths
1. **Strict Separation of Concerns**: Third-party API provider code (`windsor.provider.js`) is completely isolated from controllers and database models.
2. **Robust Multi-Tenant Security**: `organization-auth.middleware.js` prevents cross-organization data leakage.
3. **Stateless JWT Sessions**: Session verification relies on secure HttpOnly cookies.

### Weaknesses
1. **Synchronous External API Dependencies**: Analytics pages pull data directly from Windsor.ai on request. If Windsor.ai responds slowly (e.g. 3-5 seconds), the user experience suffers.
2. **Missing Request-Level Caching**: Frequent dashboard navigation causes redundant external API requests for identical date ranges.
3. **No Background Worker Queue**: Long-running data ingestion runs synchronously inside Express web worker threads.
