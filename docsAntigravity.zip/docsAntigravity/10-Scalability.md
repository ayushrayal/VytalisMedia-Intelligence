# 10 - Scalability Audit & User Capacity Estimation

This document provides a code-based scalability assessment and active user capacity estimation for Vytalis Intelligence.

> [!NOTE]
> **Assessment Basis**: Code-based estimate only. Assumes deployment on a single standard cloud application container (1 vCPU, 1 GB - 2 GB RAM, 10 MongoDB pool connections).

---

## Concurrent User Capacity Estimates

| Concurrent Active Users | System Risk Level | Estimated Response Time | Architecture Status | Primary Bottleneck |
| :---: | :---: | :---: | :--- | :--- |
| **10 Users** | **LOW** | < 500 ms (Local) / ~1.5s (Windsor) | Fully Supported | None. MongoDB connection pool (size 10) easily handles load. |
| **50 Users** | **MEDIUM** | 2s - 4s | Supported with minor delay | External Windsor API rate limits and connection queueing. |
| **100 Users** | **HIGH** | 5s - 10s | Performance Degradation | Express event loop delays due to synchronous external API waiting. |
| **500 Users** | **CRITICAL** | 15s+ / Timeout (504) | Unstable / High Failure | Windsor API timeout limit (15s in `windsor.provider.js`) triggered. |
| **1000 Users** | **FATAL** | Connection Refused / 502 | System Failure | Node.js process memory exhaustion & thread starvation. |

---

## Key Scalability Bottlenecks Identified

### 1. Synchronous External API Dependencies
- **Problem**: When a user opens `/meta/overview`, the backend synchronously calls the Windsor.ai REST API via Axios. The backend worker thread remains blocked waiting for Windsor's response.
- **Why it limits scale**: As user count grows, concurrent HTTP requests to Windsor accumulate. Windsor rate limits or latency spikes will instantly degrade all platform dashboards.

### 2. Lack of Background Data Sync & Ingestion Workers
- **Problem**: Analytics data is not pre-fetched or cached in MongoDB. Every dashboard view fetches fresh data directly from the external provider pipeline.
- **Solution**: Implement an asynchronous cron / worker queue (e.g. BullMQ with Redis) that periodically syncs analytics data into MongoDB every 15-30 minutes.

### 3. Database Connection Pool Limits
- **Problem**: Mongoose connection pool defaults to 10 connections in `Backend/Src/config/db.js`.
- **Solution**: Increase `maxPoolSize` to 50 and introduce read replicas for analytics queries.
