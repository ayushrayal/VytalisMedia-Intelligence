# 00 - Executive Summary

## What is Vytalis Intelligence?
**Vytalis Intelligence** is a multi-tenant web application designed for e-commerce businesses and digital marketing agencies. It combines advertising data (from Meta/Facebook Ads), store performance data (from Shopify), and custom order-level attribution tracking into a single unified analytics dashboard.

---

## What the System Does
1. **Aggregates Marketing & Sales Data**: Connects to Meta Ads and Shopify stores through the Windsor.ai API pipeline to calculate real-time performance metrics like Return on Ad Spend (ROAS), Cost Per Acquisition (CPA), Hook Rate, Hold Rate, Average Order Value (AOV), and customer retention.
2. **Multi-Tenant Access Control**: Segregates data safely across multiple organizations using a 4-tier role hierarchy:
   - **Root Admin**: Platform owner with full global control and system configuration rights.
   - **Admin**: Agency manager who oversees assigned Client organizations.
   - **Client**: Business owner who manages an Organization, connects integrations, and invites team members.
   - **Member**: Sub-account user with custom permission restrictions set by the Client.
3. **Custom Attribution Tracking**: Maps individual customer orders to specific traffic sources and ad campaigns.
4. **Customizable Dashboards**: Allows users to configure metric cards, customizable creative performance thresholds, and layout widgets.

---

## Main Users & User Types
| Role | Who They Are | What They Can Do |
| :--- | :--- | :--- |
| **Root Admin** | System Owner | Global permissions, manage system settings, create Admins, manage all Organizations. |
| **Admin** | Agency Account Manager | Manage assigned Client organizations, set Client permissions, inspect client performance. |
| **Client** | Brand / Business Owner | Manage brand Organization, invite Members, configure Meta/Shopify integrations. |
| **Member** | Employee / Staff | View specific dashboards and reports allowed by their Client owner. |

---

## Technology Stack Overview

### Frontend
- **Framework**: React 19
- **Build Tool**: Vite 8
- **Routing**: React Router v7
- **Styling**: Vanilla CSS with modern CSS custom properties (Variables) and dark-mode tokens
- **Icons**: Lucide React
- **Drag and Drop**: DnD Kit (@dnd-kit/core, @dnd-kit/sortable)

### Backend
- **Runtime**: Node.js (CommonJS)
- **Framework**: Express v5
- **Database ODM**: Mongoose v9 (MongoDB)
- **Caching & Rate Limiting**: Redis client v6
- **Authentication**: JSON Web Tokens (JWT in HttpOnly cookies), BcryptJS password hashing
- **Validation**: Joi v18 schema validation

### Database & External Services
- **Database**: MongoDB (Mongoose ODM)
- **Cache**: Redis
- **Data Pipeline**: Windsor.ai API provider for Meta Ads & Shopify analytics

---

## Current Architecture Highlights

```
User (Browser)
    │
    ▼
React 19 Frontend (Vite)
    │
    ▼ [Axios HTTP Client / Cookie Credentials]
Express v5 Backend Router
    │
    ├── Auth & Org Isolation Middleware (protect, requireOrganizationAccess)
    ├── Controller Layer (Request handling & response formatting)
    ├── Service Layer (Business calculations & data transformation)
    └── Adapter Layer (Windsor Provider / MongoDB queries)
          │
          ├── MongoDB (Users, Organizations, AdminAssignments, GlobalSettings)
          └── Windsor.ai API (External Meta & Shopify data connector)
```

---

## Current System Health

| Dimension | Score | Primary Rationale |
| :--- | :---: | :--- |
| **Architecture** | **8 / 10** | Clean, modular layer separation (Routes → Middleware → Controllers → Services → Adapters → Providers). |
| **Security** | **4 / 10** | **Critical Security Flaw**: Unprotected `/api/profile/upgrade-role` endpoint allows role escalation with a secret key; plain system access code required during signup. |
| **Performance** | **6 / 10** | Synchronous Windsor API calls during user dashboard loads without persistent database caching or background sync jobs. |
| **Scalability** | **5 / 10** | High dependency on real-time external API requests; potential rate-limit bottlenecks under concurrent load. |
| **Code Quality** | **7 / 10** | Consistent code style, clean error handling abstractions, though component duplication exists in UI layer. |
| **Testing** | **3 / 10** | Manual test suites exist in `Backend/Src/test-*.js`, but automated unit test framework (Jest/Vitest) is missing (`npm test` returns error). |
| **Maintainability** | **7 / 10** | Modular directory layout makes it easy to locate features, endpoints, and models. |

---

## Top 10 High-Priority Improvements

1. **Remove Admin Upgrade Endpoint**: Decommission `POST /api/profile/upgrade-role` to eliminate privilege escalation risks.
2. **Implement Automated Background Data Sync**: Cache Windsor.ai API responses in MongoDB/Redis to reduce response times from 3-5s down to <100ms.
3. **Add Automated Unit Testing Framework**: Setup Jest or Vitest for automated CI/CD validation.
4. **Deduplicate UI Components**: Combine duplicate components like `components/ui/MetricCard.jsx` and `components/shared/MetricCard.jsx`.
5. **Secure System Access Code**: Move fixed signup access code validation from hardcoded checks to database-managed invitation tokens.
6. **Optimize Database Indexes**: Add missing composite indexes for audit logs and breakdown queries.
7. **Add Request Timeout Protections**: Set strict fallback timeouts and circuit breakers for external Windsor HTTP requests.
8. **Enforce Rate Limiting Across All Endpoint Groups**: Add rate limit protection to all un-throttled routes.
9. **Clean Up Tracking of Environment Files**: Ensure `.env` files are ignored strictly by Git.
10. **Implement Client-Side Data Caching**: Standardize React Query / SWR caching across all frontend pages to prevent redundant API calls during navigation.
