# 08 - Data Flow & Lifecycle Documentation

This document traces step-by-step data flows through Vytalis Intelligence for critical user operations.

---

## 1. Authentication Data Flow (User Login)

```
[ User Inputs Email & Password ]
             │
             ▼
LoginPage.jsx (Frontend)
             │
             ▼  HTTP POST /api/auth/login
Express Router (auth.routes.js)
             │
             ▼  signupRateLimiter / loginRateLimiter
Rate Limiting Middleware (rate-limit.middleware.js)
             │
             ▼
authController.login (Backend/Src/controllers/auth.controller.js)
             │
             ▼
authService.loginUser (Backend/Src/services/auth.service.js)
             │
             ├── 1. Queries User.findOne({ email }).select("+password") from MongoDB
             ├── 2. Compares password via bcrypt.compare()
             └── 3. Generates signed JWT access token via jwt.util.js
             │
             ▼
authController.login Response
             │
             ├── Sets HttpOnly cookie named "access_token" (maxAge: 7 days)
             └── Returns JSON { success: true, user: { ... } }
             │
             ▼
React Router redirects to /overview (or /welcome for new Clients)
```

---

## 2. Meta Analytics Ingestion Flow

```
[ User Navigates to /meta/overview ]
             │
             ▼
MetaOverview.jsx (Frontend)
             │
             ▼  HTTP GET /api/meta/analytics/overview?dateFrom=...&dateTo=...
Express Router (meta.routes.js)
             │
             ├── Middleware 1: protect (JWT cookie validation)
             ├── Middleware 2: requireOrganizationAccess (multi-tenant Org resolution)
             └── Middleware 3: requireEffectivePermission("meta.overview")
             │
             ▼
metaController.getAnalyticsData (Backend/Src/controllers/meta.controller.js)
             │
             ▼
metaAnalyticsService.getAnalyticsData (Backend/Src/services/meta-analytics.service.js)
             │
             ▼
facebookAdapter.fetchOverviewData (Backend/Src/adapters/facebook.adapter.js)
             │
             ▼
windsorProvider.fetchData (Backend/Src/providers/windsor.provider.js)
             │
             ▼  Axios HTTP GET https://api.windsor.ai/v1/facebook?...
External Windsor.ai Provider API
             │
             ▼  Returns Raw JSON JSON array
windsorProvider -> facebookAdapter -> metaAnalyticsService
             │
             ├── Computes ROAS = (purchase_value / spend)
             ├── Computes CPA = (spend / purchases)
             ├── Computes Hook Rate = (video_view_3s / impressions)
             └── Computes Hold Rate = (video_view_thruplay / video_view_3s)
             │
             ▼
Returns JSON response to Frontend -> Rendered in MetricCards & Recharts
```

---

## 3. Atomic Permission Assignment Flow

```
[ Admin Edits Permissions in UserPermissionsModal.jsx ]
             │
             ▼  HTTP PATCH /api/admin/users/:userId/permissions { permissions: { "meta.campaigns": true } }
Express Router (admin.routes.js)
             │
             ├── Middleware: protect + requireAdmin + requireEffectivePermission("user_management.members")
             │
             ▼
adminController.updateUserPermissions
             │
             ▼
updateAssignedPermissionsAtomic (Backend/Src/utils/permission-calculator.util.js)
             │
             ├── Executes atomic MongoDB updateOne with $set ("assignedPermissions.$.allowed")
             └── If key does not exist, executes atomic $push to assignedPermissions array
             │
             ▼
AuditLog.create ({ action: "PERMISSION_CHANGED", actorId, targetUserId, permissionKey })
             │
             ▼
Returns updated user payload JSON -> React state updates UI inline
```

---

## 4. Unnecessary Data Movement Findings
1. **Redundant Windsor Calls**: When navigating between `/meta/overview` and `/meta/campaigns`, the backend makes two separate external HTTP queries to Windsor.ai for identical date ranges without caching the underlying raw records.
2. **Full Payload Over-Fetching**: In `meta.routes.js`, fetching breakdowns (`/campaigns/:id/breakdowns`) retrieves complete age, gender, and country datasets across all ads, transmitting 500KB+ JSON payloads when only top 5 rows are displayed in the modal.
