# 21 - New Intern Onboarding & Quick-Start Guide

Welcome to **Vytalis Intelligence**! This guide is written in plain, simple English to help you navigate the codebase confidently on your first day.

---

## 1. Simple Glossary of Terms

- **Frontend**: The visual user interface running in the user's browser (built with React 19).
- **Backend**: The server code running behind the scenes that handles data and logic (built with Node.js and Express).
- **API (Application Programming Interface)**: A communication bridge that allows the frontend to request data from the backend.
- **Database**: The persistent storage box where user accounts, settings, and organizations are saved (MongoDB).
- **Database Index**: A shortcut lookup table that helps MongoDB find specific data instantly without searching through millions of rows.
- **RBAC (Role-Based Access Control)**: A security rules engine that determines whether a user (Root Admin, Admin, Client, or Member) is allowed to see a page or click a button.
- **Adapter**: A translation helper script that converts raw data from third-party APIs (like Facebook/Shopify via Windsor.ai) into simple objects our app understands.

---

## 2. Codebase Map: Where Everything Lives

```
d:\VM Intelligence\
 │
 ├── Backend/
 │    ├── server.js                        <-- Starts the backend server on port 5000
 │    ├── package.json                     <-- Backend dependencies list
 │    └── Src/
 │         ├── app.js                      <-- Configures Express, CORS, and API routes
 │         ├── routes/                     <-- API route URL definitions (/api/auth, /api/meta, etc.)
 │         ├── controllers/                <-- Request handlers (processes inputs and sends responses)
 │         ├── services/                   <-- Business calculations (ROAS, CPA, sales metrics)
 │         ├── models/                     <-- MongoDB database schemas (User, Organization, AuditLog)
 │         ├── middleware/                 <-- Security guards (JWT auth, multi-tenant org checks)
 │         ├── adapters/                   <-- Windsor API data transformers (Meta, Shopify)
 │         ├── providers/                  <-- Windsor HTTP provider (windsor.provider.js)
 │         ├── config/                     <-- Database config and permission registry lists
 │         └── utils/                      <-- Permission calculator & helper utilities
 │
 └── Frontend/
      ├── package.json                     <-- Frontend dependencies list
      ├── vite.config.js                   <-- Vite build configuration
      └── src/
           ├── main.jsx                    <-- Frontend entry bootstrap
           ├── app/router.jsx              <-- Client route definitions and permission guards
           ├── features/                   <-- Page modules grouped by feature (admin, meta, shopify)
           ├── components/                 <-- Reusable UI buttons, inputs, modals, cards
           ├── layouts/                    <-- Page wrappers (AuthLayout, DashboardLayout)
           ├── lib/http.js                 <-- Axios HTTP client instance for backend API calls
           └── index.css                   <-- Global CSS colors, fonts, and dark mode tokens
```

---

## 3. Key Concept Locations

1. **Where Authentication Lives**:
   - Backend Token Guard: [`Backend/Src/middleware/auth.middleware.js`](file:///d:/VM%20Intelligence/Backend/Src/middleware/auth.middleware.js#L11)
   - Login & Signup Logic: [`Backend/Src/services/auth.service.js`](file:///d:/VM%20Intelligence/Backend/Src/services/auth.service.js)
   - Frontend Session Restore: `restoreSession()` in [`Frontend/src/app/router.jsx`](file:///d:/VM%20Intelligence/Frontend/src/app/router.jsx#L356)

2. **Where Multi-Tenant Organization Isolation Lives**:
   - Guard Middleware: [`Backend/Src/middleware/organization-auth.middleware.js`](file:///d:/VM%20Intelligence/Backend/Src/middleware/organization-auth.middleware.js#L33)

3. **Where Permissions & RBAC Live**:
   - Permission Keys List: [`Backend/Src/config/permission-registry.js`](file:///d:/VM%20Intelligence/Backend/Src/config/permission-registry.js)
   - Effective Permission Calculator: [`Backend/Src/utils/permission-calculator.util.js`](file:///d:/VM%20Intelligence/Backend/Src/utils/permission-calculator.util.js#L98)
   - Frontend Route Guard: [`Frontend/src/components/shared/PermissionRouteGuard.jsx`](file:///d:/VM%20Intelligence/Frontend/src/components/shared/PermissionRouteGuard.jsx)

4. **Where Integrations Live**:
   - Windsor HTTP Client: [`Backend/Src/providers/windsor.provider.js`](file:///d:/VM%20Intelligence/Backend/Src/providers/windsor.provider.js)
   - Meta Adapter: [`Backend/Src/adapters/facebook.adapter.js`](file:///d:/VM%20Intelligence/Backend/Src/adapters/facebook.adapter.js)
   - Shopify Adapter: [`Backend/Src/adapters/shopify.adapter.js`](file:///d:/VM%20Intelligence/Backend/Src/adapters/shopify.adapter.js)

---

## 4. How-To Developer Workflows

### How to Add a New Page
1. Create a new JSX page component inside `Frontend/src/features/<feature_name>/pages/MyNewPage.jsx`.
2. Open `Frontend/src/app/router.jsx`.
3. Import your page at the top.
4. Register a new route inside `<Routes>` wrapped with `<ProtectedRoute>` and `<PermissionRouteGuard>`:
   ```jsx
   <Route path="/my-new-page" element={
     <PermissionRouteGuard permissionKey={PERMISSION_KEYS.MY_NEW_PERM}>
       <MyNewPage />
     </PermissionRouteGuard>
   } />
   ```

### How to Add a New API Endpoint
1. Open the relevant route file (e.g. `Backend/Src/routes/meta.routes.js`).
2. Define the route with middleware protections:
   ```js
   router.get("/my-endpoint", requireEffectivePermission("meta.view"), metaController.getMyData);
   ```
3. Add handler function in `Backend/Src/controllers/meta.controller.js`.
4. Add business logic calculation in `Backend/Src/services/meta-analytics.service.js`.

### How to Add a New Permission Key
1. Open [`Backend/Src/config/permission-registry.js`](file:///d:/VM%20Intelligence/Backend/Src/config/permission-registry.js).
2. Add your new permission key (e.g. `"meta.custom_report"`) to `PERMISSION_REGISTRY`.
3. Open [`Frontend/src/config/permission-registry.js`](file:///d:/VM%20Intelligence/Frontend/src/config/permission-registry.js) and add the matching key to `PERMISSION_KEYS`.

---

## 5. How to Run Locally

### 1. Start the Backend Server
```bash
cd Backend
npm install
npm run dev
```
*(Runs backend server at http://localhost:5000)*

### 2. Start the Frontend Application
```bash
cd Frontend
npm install
npm run dev
```
*(Runs Vite dev server at http://localhost:5173)*

---

## 6. Critical Files an Intern Should NOT Modify Casually

> [!CAUTION]
> The following core security and database files should never be edited without senior developer review:

1. [`Backend/Src/middleware/auth.middleware.js`](file:///d:/VM%20Intelligence/Backend/Src/middleware/auth.middleware.js): Handles JWT verification and user authentication guards.
2. [`Backend/Src/middleware/organization-auth.middleware.js`](file:///d:/VM%20Intelligence/Backend/Src/middleware/organization-auth.middleware.js): Guarantees multi-tenant organization boundary security.
3. [`Backend/Src/utils/permission-calculator.util.js`](file:///d:/VM%20Intelligence/Backend/Src/utils/permission-calculator.util.js): Core 7-step RBAC cascade calculator.
4. [`Backend/Src/config/db.js`](file:///d:/VM%20Intelligence/Backend/Src/config/db.js): Database connection settings.
5. [`Backend/Src/app.js`](file:///d:/VM%20Intelligence/Backend/Src/app.js): Express CORS, cookies, and top-level middleware config.
