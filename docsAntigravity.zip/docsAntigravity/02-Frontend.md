# 02 - Frontend Audit & Page Inventory

This document provides a comprehensive audit of the Vytalis Intelligence frontend application.

---

## Technical Stack
- **Library**: React 19
- **Build System**: Vite 8
- **Routing**: React Router v7 (`react-router-dom`)
- **Linter**: Oxlint (`oxlintrc.json`)
- **Drag and Drop**: DnD Kit (`@dnd-kit/core`, `@dnd-kit/sortable`)
- **Icons**: Lucide React (`lucide-react`)
- **Styling**: Pure Vanilla CSS with global CSS custom properties in `Frontend/src/index.css`.

---

## Routing & Layout Architecture

```
BrowserRouter (Frontend/src/app/router.jsx)
 │
 ├── PublicRoute -> AuthLayout -> LoginPage (/login), SignupPage (/signup)
 ├── WelcomeRoute -> Welcome (/welcome)
 └── ProtectedRoute -> DashboardLayout
      ├── Global Overview (/overview)
      ├── Profile (/profile)
      ├── Admin Routes (AdminRouteGuard) -> UserManagement (/admin/users)
      ├── Team Routes (ClientRouteGuard) -> ClientTeamManagement (/team)
      ├── Attribution (PermissionRouteGuard) -> AttributionOverview (/attribution)
      ├── Meta Analytics (PermissionRouteGuard)
      │    ├── MetaOverview (/meta/overview)
      │    ├── Campaigns (/meta/campaigns)
      │    ├── AdSets (/meta/adsets)
      │    ├── Creatives (/meta/creatives)
      │    ├── WinningCreatives (/meta/winning-creatives)
      │    ├── PoorPerformers (/meta/poor-performers)
      │    ├── Audience (/meta/audience)
      │    ├── Places (/meta/places)
      │    └── MetaCompare (/meta/compare)
      ├── Shopify Analytics (PermissionRouteGuard)
      │    ├── ShopifyOverview (/shopify/overview)
      │    ├── ShopifyOrders (/shopify/orders)
      │    ├── ShopifyProducts (/shopify/products)
      │    ├── ShopifyCustomers (/shopify/customers)
      │    ├── ShopifyLocation (/shopify/location)
      │    └── ShopifyCompare (/shopify/compare)
      └── Integrations
           ├── MetaAccounts (/integrations/meta)
           ├── ShopifyAccounts (/integrations/shopify)
           └── GoogleIntegration (/integrations/google)
```

---

## Complete Page Inventory (26 Pages)

| # | Page Name | Route | Required Permission | Main API Calls | Main Components Used | Purpose & Function |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | **LoginPage** | `/login` | Public | `POST /api/auth/login` | `AuthLayout`, `Input`, `Button` | Authenticates users and stores JWT session cookie. |
| 2 | **SignupPage** | `/signup` | Public | `POST /api/auth/signup` | `AuthLayout`, `Input`, `Button` | Registers new accounts using system access code. |
| 3 | **Welcome** | `/welcome` | Client (onboarding) | `POST /api/meta/accounts` | `AppLogo`, `Button`, `Input` | Guides new Client users through connecting Meta accounts. |
| 4 | **DashboardOverview** | `/overview` | `dashboard.view` | `GET /api/profile/kpi-preferences`, `GET /api/meta/analytics/overview`, `GET /api/shopify/overview` | `DashboardGrid`, `DashboardWidget`, `BusinessDashboardCustomizer` | Central customizable business performance overview. |
| 5 | **Profile** | `/profile` | Authenticated | `GET /api/profile`, `PUT /api/profile/kpi-preferences`, `POST /api/profile/upgrade-role` | `Input`, `Button`, `Modal` | Manage account profile, KPI card choices, and admin upgrade key. |
| 6 | **UserManagement** | `/admin/users` | Admin / Root Admin | `GET /api/admin/users/counts`, `GET /api/admin/users/admins`, `GET /api/admin/users/clients`, `GET /api/admin/users/members`, `PATCH /api/admin/users/:id/permissions` | `AddUserModal`, `AddMemberModal`, `UserPermissionsModal` | Complete user, role, and permission administration. |
| 7 | **ClientTeamManagement** | `/team` | Client | `GET /api/client/team`, `POST /api/client/team`, `PATCH /api/client/team/:id/permissions` | `Modal`, `Input`, `Button`, `UserPermissionsModal` | Client organization team member onboarding & permissions. |
| 8 | **AttributionOverview** | `/attribution` | `attribution.view` | `GET /api/attribution/overview`, `GET /api/attribution/orders` | `MetricCard`, `ColumnCustomizer` | Order-level multi-touch traffic source attribution. |
| 9 | **MetaOverview** | `/meta/overview` | `meta.overview` | `GET /api/meta/analytics/overview` | `MetricCard`, `CompareChart` | Aggregate Meta ad spend, ROAS, CPA, and conversions. |
| 10 | **Campaigns** | `/meta/campaigns` | `meta.campaigns` | `GET /api/meta/analytics/campaigns`, `GET /api/meta/campaigns/:id/details` | `ColumnCustomizer`, `MetricCard` | Meta campaign breakdown tables and details modal. |
| 11 | **AdSets** | `/meta/adsets` | `meta.adsets` | `GET /api/meta/analytics/adsets`, `GET /api/meta/adsets/:id/breakdowns` | `ColumnCustomizer`, `MetricCard` | Meta ad set targeting, placement, and breakdown insights. |
| 12 | **Creatives** | `/meta/creatives` | `meta.creatives` | `GET /api/meta/analytics/creatives`, `GET /api/meta/ads/:id/breakdowns` | `MetricCard`, `ColumnCustomizer` | Ad creative cards, video hook/hold rates, and metrics. |
| 13 | **WinningCreatives** | `/meta/winning-creatives` | `meta.winning_creatives` | `GET /api/meta/analytics/creatives` | `MetricCard`, `Button` | Filters top-performing ad creatives based on ROAS thresholds. |
| 14 | **PoorPerformers** | `/meta/poor-performers` | `meta.poor_performers` | `GET /api/meta/analytics/creatives` | `MetricCard`, `Button` | Flags high-spend, low-ROAS creatives needing pause. |
| 15 | **Audience** | `/meta/audience` | `meta.audience` | `GET /api/meta/analytics/audience` | `MetricCard`, `CompareChart` | Demographic breakdowns (age group, gender distribution). |
| 16 | **Places** | `/meta/places` | `meta.places` | `GET /api/meta/analytics/places` | `MetricCard`, `CompareTable` | Geographic ad spend and conversion analytics by region/city. |
| 17 | **MetaCompare** | `/meta/compare` | `meta.compare` | `GET /api/meta/compare` | `MetricCompareGrid`, `CompareChart`, `DateRangeCompareSelector` | Compares Meta ad performance across two custom date ranges. |
| 18 | **ShopifyOverview** | `/shopify/overview` | `shopify.overview` | `GET /api/shopify/overview` | `MetricCard`, `CompareChart` | Store revenue, total orders, discounts, and AOV summary. |
| 19 | **ShopifyOrders** | `/shopify/orders` | `shopify.orders` | `GET /api/shopify/orders` | `MetricCard`, `ColumnCustomizer` | Shopify sales order records, payment status, and channels. |
| 20 | **ShopifyProducts** | `/shopify/products` | `shopify.products` | `GET /api/shopify/products` | `MetricCard`, `ColumnCustomizer` | Product inventory sales, units sold, and revenue breakdown. |
| 21 | **ShopifyCustomers** | `/shopify/customers` | `shopify.customers` | `GET /api/shopify/customers` | `MetricCard`, `ColumnCustomizer` | New vs returning customer analytics and cohort data. |
| 22 | **ShopifyLocation** | `/shopify/location` | `shopify.location` | `GET /api/shopify/location` | `MetricCard`, `CompareTable` | Regional sales density and shipping location distribution. |
| 23 | **ShopifyCompare** | `/shopify/compare` | `shopify.compare` | `GET /api/shopify/compare` | `MetricCompareGrid`, `CompareChart`, `DateRangeCompareSelector` | Compares store revenue metrics across two custom date ranges. |
| 24 | **ShopifyAccounts** | `/integrations/shopify` | `shopify.view` | `GET /api/shopify/accounts`, `POST /api/shopify/accounts` | `Modal`, `Input`, `Button` | Connect and manage active Shopify store integrations. |
| 25 | **MetaAccounts** | `/integrations/meta` | `meta.view` | `GET /api/meta/accounts`, `POST /api/meta/accounts` | `Modal`, `Input`, `Button` | Connect and set active Meta Ad account. |
| 26 | **GoogleIntegration** | `/integrations/google` | Authenticated | None (Static view) | `PageHeader`, `Button` | Placeholder page for upcoming Google Ads integration. |

---

## Core Frontend Findings & Identified Issues

### 1. Duplicate UI Components
- **Exact File**: `Frontend/src/components/ui/MetricCard.jsx` (3.4 KB) vs `Frontend/src/components/shared/MetricCard.jsx` (1.4 KB)
- **Problem**: Two separate implementations of the metric card component exist in the codebase.
- **Impact**: Inconsistent rendering, potential maintenance confusion when updating design tokens.
- **Fix**: Consolidate into `components/ui/MetricCard.jsx` and delete the duplicate shared component.

### 2. Oversized / Monolithic Components
- **Exact Files**:
  - [`UserManagement.jsx`](file:///d:/VM%20Intelligence/Frontend/src/features/admin/pages/UserManagement.jsx) (39.5 KB, ~900 lines)
  - [`DashboardWidget.jsx`](file:///d:/VM%20Intelligence/Frontend/src/components/dashboard/DashboardWidget.jsx) (30.0 KB)
  - [`BusinessDashboardCustomizer.jsx`](file:///d:/VM%20Intelligence/Frontend/src/components/dashboard/BusinessDashboardCustomizer.jsx) (26.9 KB)
  - [`UserPermissionsModal.jsx`](file:///d:/VM%20Intelligence/Frontend/src/features/admin/components/UserPermissionsModal.jsx) (25.7 KB)
  - [`DashboardLayout.jsx`](file:///d:/VM%20Intelligence/Frontend/src/layouts/DashboardLayout.jsx) (23.9 KB)
  - [`ShopifyOverview.jsx`](file:///d:/VM%20Intelligence/Frontend/src/features/shopify/pages/ShopifyOverview.jsx) (23.5 KB)
- **Problem**: These components contain excessive inline state, raw table rendering, modal dialogs, and permission checking logic all in one file.
- **Fix**: Refactor large pages into sub-components (e.g. `UserTable.jsx`, `AdminTab.jsx`, `ClientTab.jsx`).

### 3. Lack of Client-Side Data Caching
- **Problem**: Frontend relies on vanilla `useEffect` data fetching. Navigating back and forth between `/meta/overview` and `/meta/campaigns` triggers full, un-cached network calls every time.
- **Fix**: Standardize data fetching using TanStack Query (React Query) or SWR to introduce automatic query caching and background revalidation.
